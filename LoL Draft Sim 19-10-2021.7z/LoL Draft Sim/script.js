var items = [];
var selected_champs = [];
var team1;
var team2;
var pick_seq = 1;
var pick_phase = 1;
var championlist = [];
var championlist2 = [];
var championsimages;

class Team {
  constructor(n,s){
    this.name = n;
    this.side = s;
    this.bans = [];
    this.picks = [];
  }

  Ban(b){
    if(this.bans.length<5){
      this.bans.push(b);
      return 1;
    }
    else{
      return 0;
    }
    
  }
  
  Pick(p){
    if(this.picks.length<5){
      this.picks.push(p);
      return 1;
    }
    else{
      return 0;
    }
  }
};


$(document).ready(function(){
  champions = [];
  championlist = [];
  championlist2 = [];
  $.getJSON(
    'http://ddragon.leagueoflegends.com/cdn/11.19.1/data/en_US/champion.json', 
    function(data, status){
      if(status = 'success'){
        //alert("Data: " + data + "\nStatus: " + status);
        champions = data.data;
        console.log(champions);

        $.each( champions, function( key, val ) {//function to be depricated as championlist is to be completely replace by championlist2
          championlist.push(val.name);
        });

        $.each( champions, function( key, val ) {
          championlist2.push({"Name": val.name, "ID": val.id, "image": val.image.full});//build array of champion data to access
        });

        buildList2(championlist);//to replace with championlist2
        
      }
      else{
        alert("Status: " + status);
      }
    //alert("\nStatus: " + status);
    }
  );
  
  //console.log(champions);
  console.log(championlist2);
  //console.log(championlist);

  IntializeTeams();//Set up team objects
  console.log(team1);
  console.log(team2);
  //team1.Ban("Aatrox");

  //Initialize Picks and bans
  updatePicks(team1);
  updatePicks(team2);
  updateBans(team1);
  updateBans(team2);
});

function IntializeTeams(){
  team1=CreateTeam('Team A',1);
  team2=CreateTeam('Team B',2);
}

function CreateTeam(tname,side){
  t = new Team(tname,side);
  return t;
}

function BanPhase1(){
  alert("Press 'OK' Begin Ban Phase");
  //Team1 Ban pick_seq =0
  //document.getElementsByClassName("champion-i").addEventListener('click', banchamp(team1) );
  //Team2 Ban pick_seq =0
  //Team1 Ban pick_seq =0
  //Team2 Ban pick_seq =0
  //Team1 Ban pick_seq =0
  //Team2 Ban pick_seq =0
}

function FilterChamps(){//update visible champions in grid on search bar input
  var str = document.getElementById("champ_search").value;
  for(var i in championlist){//to replace with championlist2
    
    if(!championlist[i].toLowerCase().includes(str)){
      var champ = document.getElementById('champion-'+i);
      var x = champ.parentNode;
      x.style.display = 'none';
      champ.style.display = 'none';
      //console.log(championlist[i]+' found in search');
    }
    else{
      var champ = document.getElementById('champion-'+i);
      var x = champ.parentNode;
      x.style.display = 'inline-block';
      champ.style.display = 'inline-block';
    }

  }
}

function UpdateGridUI(champid){
  
  var champ = document.getElementById('champion-'+champid);
  var div = champ.parentNode;
  div.classList.add("unavailable");
  console.log(div);

}


function GetPhase(){
  if(pick_seq >= 1 && pick_seq <= 6){
    return 1;//3 bans per team
  }
  if(pick_seq >= 7 && pick_seq <= 12){
    return 2;//3 picks per team
  }
  if(pick_seq >= 13 && pick_seq <= 16){
    return 3;//2 bans per team
  }
  if(pick_seq >= 17 && pick_seq <= 20){
    return 4;//2 Picks per team
  }
}

$(document).on('input', '#champ_search', function (event) {//Handles all champion selection events
  FilterChamps();
});

$(document).on('click', '.champion-i', function (event) {//Handles all champion selection events

  //console.log('Pick Seq:'+pick_seq);
  var htmlid = event.target.id;
  var x = document.getElementById(htmlid).innerHTML;
  if(team1.bans.indexOf(x) != -1 || team1.picks.indexOf(x) != -1 || team2.bans.indexOf(x) != -1 || team2.picks.indexOf(x) != -1){
    alert('Selected Champion is already picked or banned.');
    return;
  }

  if(GetPhase() == 1){//1st 3 bans per team
    if(pick_seq%2 == 1){
      console.log('Team 1 Ban selection');
      banchamp(team1,event.target.id);
    }
    else{
      console.log('Team 2 Ban selection');
      banchamp(team2,event.target.id);
    }
  }

  if(GetPhase() == 2){//1st 3 picks per team
    if(pick_seq == 7 || pick_seq == 10 || pick_seq == 11){
      console.log('Team 1 Pick selection');
      pickchamp(team1,event.target.id);
    }
    else{
      console.log('Team 2 Pick selection');
      pickchamp(team2,event.target.id);
    }
  }

  if(GetPhase() == 3){//final 2 bans per team
    if(pick_seq%2 == 0){
      console.log('Team 1 Ban selection');
      banchamp(team1,event.target.id);
    }
    else{
      console.log('Team 2 Ban selection');
      banchamp(team2,event.target.id);
    }
  }

  if(GetPhase() == 4){//final 2 picks per team
    if(pick_seq == 18 || pick_seq == 19){
      console.log('Team 1 Pick selection');
      pickchamp(team1,event.target.id);
    }
    else{
      console.log('Team 2 Pick selection');
      pickchamp(team2,event.target.id);
    }
  }

  //console.log('Pick Seq%2:'+pick_seq%2);
  console.log(pick_seq);
  pick_seq++;
});



function pickchamp(team,id){
  //console.log(team);
  //console.log('Event: Pick '+id);
  var res = team.Pick(document.getElementById(id).innerHTML);//pick champ by inserting id into team.picks[]
  //updateBans(team);
  //console.log(team.picks.length);
  //console.log(team.picks);
  if(res == 1){
    updatePickUI(team,id);
  }
  else{
    pick_phase++;
    alert("Team has no picks remaining");
  }
}

function banchamp(team,id){
  //console.log(team);
  //console.log('Event: Ban '+id);
  var res = team.Ban(document.getElementById(id).innerHTML);//ban champ by inserting id into team.bans[]
  //updateBans(team);
  //console.log(team.bans.length);
  //console.log(team.bans);
  if(res == 1){
    updateBanUI(team,id);
  }
  else{
    pick_phase++;
    alert("Team has no bans remaining");
  }

}

function updateBanUI(team,id){
  var pick = document.getElementById('ban-'+team.side+'-'+(team.bans.length-1));
  var champid = id.substring(9);
  //var champsplash = championlist2[champid].ID;
  //var skin = '_0'; 
  //champsplash += skin + '.jpg';

  pick.innerHTML = document.getElementById(id).innerHTML;
  //championlist2[champid].ID;
  pick.style.backgroundImage = 'url(http://ddragon.leagueoflegends.com/cdn/11.20.1/img/champion/'+championlist2[champid].image+')';
  pick.style.backgroundSize = 'cover';

  UpdateGridUI(champid);
}

function updatePickUI(team,id){
  var pick = document.getElementById('pick-'+team.side+'-'+(team.picks.length-1));
  var champid = id.substring(9);
  var champsplash = championlist2[champid].ID;
  var skin = '_0'; 
  champsplash += skin + '.jpg';

  pick.innerHTML = document.getElementById(id).innerHTML;
  championlist2[champid].ID;
  pick.style.backgroundImage = 'url(http://ddragon.leagueoflegends.com/cdn/img/champion/loading/'+champsplash+')';
  pick.style.backgroundSize = 'cover';

  UpdateGridUI(champid);
}


function updateBans(team){//function to update bans ui
  ul = document.createElement('ul');
  var replace = document.getElementById('team-bans-'+team.side);

  document.getElementById('team-bans-'+team.side).appendChild(ul);

  for(let i = 0; i < 5; i++){
    //console.log("loop: "+i);
    var str = "ban-";
    str += team.side + "-";
    str += i;
    //console.log("str="+str);
    let li = document.createElement('li');
    li.setAttribute('class', 'ban-i');
    li.setAttribute('id', str);
    ul.appendChild(li);
    
    if(i in team.bans){
      //console.log("ban["+i+"] exists")
      li.innerHTML += team.bans[i];
    }
    else{
      //console.log("ban["+i+"] empty")
      li.innerHTML += "None";
    }
    //console.log("innerhtml:"+li.innerHTML)
    
  }

}


function updatePicks(team){//function to update picks ui
  ul = document.createElement('ul');
  var replace = document.getElementById('team-picks-'+team.side);
  document.getElementById('team-picks-'+team.side).appendChild(ul);

  for(let i = 0; i < 5; i++){
    //console.log("loop: "+i);
    var str = "pick-";
    str += team.side + "-";
    str += i;
    //console.log("str="+str);
    let li = document.createElement('li');
    li.setAttribute('class', 'pick-i');
    li.setAttribute('id', str);
    //li.style.backgroundImage = 'url(http://ddragon.leagueoflegends.com/cdn/11.20.1/img/champion/'+championlist2[i].image+')';
    //li.style.backgroundSize = 'cover';
    ul.appendChild(li);
    
    if(i in team.picks){
      //console.log("ban["+i+"] exists")
      li.innerHTML += team.picks[i];
    }
    else{
      //console.log("ban["+i+"] empty")
      li.innerHTML += "None";
    }
    //console.log("innerhtml:"+li.innerHTML)
    
  }

}


function buildList2(items){//populate champion grid
  //console.log("items array in BuildList2:");
  //console.log(items);
  //console.log('arraySize='+items.length);
  ul = document.createElement('ul');
  

  document.getElementById('champion-grid').appendChild(ul);
  

  var champid = 0;
  for(var i in items){
    let div = document.createElement('div');
    div.setAttribute('class', 'champion');
    
    let li = document.createElement('li');

    li.setAttribute('class', 'champion-i');
    li.setAttribute('id', 'champion-'+champid);
    li.style.backgroundImage = 'url(http://ddragon.leagueoflegends.com/cdn/11.20.1/img/champion/'+championlist2[i].image+')';
    li.style.backgroundSize = 'cover';

    div.appendChild(li);
    ul.appendChild(div);
    //ul.appendChild(li);
    
    //li.innerHTML += items[i];
    li.innerHTML += i;
    div.innerHTML += championlist2[i].Name;
    champid++;
  }

}
